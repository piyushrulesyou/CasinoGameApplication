package com.nagarro.adminPanel.services;

import com.nagarro.adminPanel.model.CustomerDetails;

public interface UserRegistrationServices {

	public String registerUser(CustomerDetails userInformation);

}