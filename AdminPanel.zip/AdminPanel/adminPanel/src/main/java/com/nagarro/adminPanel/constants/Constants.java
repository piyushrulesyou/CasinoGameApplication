package com.nagarro.adminPanel.constants;

public class Constants {
	public static final String DATEFORMAT = "yyyy-MM-dd";
//	public static final String FOLDERPATH = "<D:\\TRAINING-Nagarro\\ApplicationDevelopment-1\\Assignment Links\\Assignment Links\\>";
}
