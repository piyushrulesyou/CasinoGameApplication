package com.nagarro.adminPanel.services;

public interface RechargeWalletServices {

	public void rechargeWallet(String customerID, double rechargeAmount);

}
