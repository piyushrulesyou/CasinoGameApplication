//package com.nagarro.adminPanel.dao;
//
//import com.nagarro.adminPanel.model.CustomerDetails;
//
//public interface AdjustFinalAmountDao {
//
//	public CustomerDetails fetchCustomerDetails(String customerID);
//
//	public void updateCustomerDetails(CustomerDetails userInformation);
//
//}